package JointVO;


/**
 * The shape of all element.
 */
public class Path {
	String d;

//	private String fill = "RED";
	public Path(String d) {
		super();
		this.d = d;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}
	
}
