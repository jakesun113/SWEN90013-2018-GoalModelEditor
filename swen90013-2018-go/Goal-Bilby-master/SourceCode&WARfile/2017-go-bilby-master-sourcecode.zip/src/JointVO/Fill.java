package JointVO;

import com.google.gson.annotations.SerializedName;


/**
 * this is an attribute of link.
 */
public class Fill {
    @SerializedName("fill")
    String d = "none";
}