package basicVO;

// basic json object for emotion
public class Emotion extends AbstactObject{
	String emotion;
}
