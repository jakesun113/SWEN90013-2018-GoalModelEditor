package basicVO;


public class Quality extends AbstactObject{
	String quality;

	public String getQuality() {
		return quality;
	}

	public void setQuality(String quality) {
		this.quality = quality;
	}
	
}
