package basicVO;


public class Role extends AbstactObject{
	String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
